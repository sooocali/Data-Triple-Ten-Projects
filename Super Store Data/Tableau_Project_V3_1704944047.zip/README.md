
# Project Title

This Tableau Project is a culmination of the material I learned through Triple Ten. This project showcases analysis on stores, products, and exmination of profitability.

The link for my tableau project is below.


https://public.tableau.com/views/SuperStoredataTableauanalysis/Dashboard1?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link

